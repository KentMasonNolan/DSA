package Lab4;

public class Node {
    public String data;
    public Node next;
}
