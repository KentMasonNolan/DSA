package Week1;

public class Quiz {
}
