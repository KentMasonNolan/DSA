package Assignment1.Question_2;

class GeneratedNumber {
    int number;
    int posX;
    int posY;

    public GeneratedNumber(int number, int posX, int posY) {
        this.number = number;
        this.posX = posX;
        this.posY = posY;
    }
}

