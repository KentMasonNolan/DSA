package Assignment1.Question_3;

public interface ShipPositionCallback {
    void onPositionUpdated();

    void setCrashMessage(String s);
}
