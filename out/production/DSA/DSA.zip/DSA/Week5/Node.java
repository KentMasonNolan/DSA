package Week5;

public class Node {

    public  String data;
    public  Node prev;
    public  Node next;
}
